public class wunderCal {

    public static void main(String[] args) {

        //Calls the runUI method that controls the entire applications UI (console output)
        wunderCalUI.runUI();

    }

}
